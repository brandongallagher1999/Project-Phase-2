
let id = 0;

const addItem = ()=>
{
    let inputField = document.getElementById("todoinput");
    let text = inputField.value;

    let table = document.getElementsByTagName("table")[0];

    let tbody = table.children[1];

    let trow = document.createElement("tr"); 
    trow.setAttribute("id", id.toString());

    let tr0 = document.createElement("th");//To Do Item Description 
    tr0.innerHTML = text;

    let tr1 = document.createElement("th"); // check box
    let checkbox = document.createElement("input");
    checkbox.onclick = ()=> {     //ez pz function
        trow.setAttribute("style", "text-decoration: line-through");
        let audio = new Audio("sound.mp3");
        audio.play();
    }
    checkbox.setAttribute("type", "checkbox");
    tr1.appendChild(checkbox);

    let tr2 = document.createElement("th"); // Delete button
    let delete_button = document.createElement("button");
    delete_button.innerHTML = "Delete Item";
    delete_button.setAttribute("class", "button is-danger");
    delete_button.onclick = ()=>{ trow.remove();}
    tr2.appendChild(delete_button);

 

    trow.appendChild(tr0);
    trow.appendChild(tr1);
    trow.appendChild(tr2);

    tbody.appendChild(trow);

}


let button = document.getElementById("btn_todo");

button.onclick = addItem;


